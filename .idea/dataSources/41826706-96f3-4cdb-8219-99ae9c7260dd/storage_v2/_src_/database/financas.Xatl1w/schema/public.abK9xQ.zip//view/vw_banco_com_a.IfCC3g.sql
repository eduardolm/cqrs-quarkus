create view vw_banco_com_a(numero, nome, ativo) as
SELECT vw_bancos_ativos.numero,
       vw_bancos_ativos.nome,
       vw_bancos_ativos.ativo
FROM vw_bancos_ativos
WHERE vw_bancos_ativos.nome::text ~~* 'a%'::text
with local check option;

alter table vw_banco_com_a
    owner to postgres;


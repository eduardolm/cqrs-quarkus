create view vw_bancos_2(banco_numero, banco_nome, banco_ativo) as
SELECT banco.numero AS banco_numero,
       banco.nome   AS banco_nome,
       banco.ativo  AS banco_ativo
FROM banco;

alter table vw_bancos_2
    owner to postgres;


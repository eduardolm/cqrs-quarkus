create view vw_func(id, gerente, funcionario) as
WITH RECURSIVE vw_func(id, gerente, funcionario) AS (
    SELECT funcionarios.id,
           funcionarios.gerente,
           funcionarios.nome
    FROM funcionarios
    WHERE funcionarios.gerente IS NULL
    UNION ALL
    SELECT funcionarios.id,
           funcionarios.gerente,
           funcionarios.nome
    FROM funcionarios
             JOIN vw_func vw_func_1 ON vw_func_1.id = funcionarios.gerente
)
SELECT vw_func.id,
       vw_func.gerente,
       vw_func.funcionario
FROM vw_func;

alter table vw_func
    owner to postgres;


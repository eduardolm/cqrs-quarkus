create function bancos_add(p_numero integer, p_nome character varying, p_ativo boolean) returns integer
    language plpgsql
as
$$
declare var_id integer;
begin
	if p_numero is null or p_nome is null or p_ativo is null then
		return 0;
	end if;
	select into var_id numero
	from banco
	where numero = p_numero;
	
	if var_id is null then
		insert into banco(numero, nome, ativo)
		values(p_numero, p_nome, p_ativo);
	else
		return var_id;
	end if;
	
	select into var_id numero
	from banco
	where numero = p_numero;
	
	return var_id;
end;
$$;

alter function bancos_add(integer, varchar, boolean) owner to postgres;


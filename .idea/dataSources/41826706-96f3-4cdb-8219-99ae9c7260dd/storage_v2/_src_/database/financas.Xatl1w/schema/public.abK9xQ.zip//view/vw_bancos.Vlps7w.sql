create view vw_bancos(numero, nome, ativo) as
SELECT banco.numero,
       banco.nome,
       banco.ativo
FROM banco;

alter table vw_bancos
    owner to postgres;


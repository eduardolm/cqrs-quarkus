create view vw_bancos_ativos(numero, nome, ativo) as
SELECT banco.numero,
       banco.nome,
       banco.ativo
FROM banco
WHERE banco.ativo IS TRUE
with local check option;

alter table vw_bancos_ativos
    owner to postgres;


create function func_somar(integer, integer) returns integer
    security definer
    language sql
as
$$
select coalesce($1,0) + coalesce($2, 0)
$$;

alter function func_somar(integer, integer) owner to postgres;

